#include <cstdio>
#include <cstdlib>

#include <OpenGL/gl.h> 
#include <OpenGL/glu.h> 
#include <GLUT/glut.h>

void DrawRectangle(float midx, float midy,
                   float width, float height,
                   float r, float g, float b){
    glBegin(GL_QUADS);
        glColor3f(r, g, b);
        glVertex3f(midx - width/2, midy - height/2, 0.0);
        glVertex3f(midx + width/2, midy - height/2, 0.0);
        glVertex3f(midx + width/2, midy + height/2, 0.0);
        glVertex3f(midx - width/2, midy + height/2, 0.0);
    glEnd();
    return;
}
    
void Display(){
    glClear(GL_COLOR_BUFFER_BIT);
    DrawRectangle(0, 0, 1, 1, 0.5, 0.5, 0.5);
    glColor3f(1,1,1);
    char str[] = "HELLO OPENGL";
    glRasterPos2f(-0.5, 0);
    for(int c = 0; str[c] != 0; c++)
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, str[c]);
    glFlush();
    return;
}

void CloseFunc(){
    exit(0);
}

int main(int argc, char* argv[]){ 
    glutInit(&argc, argv);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Test Opengl");
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_ALPHA); 
    glutDisplayFunc(Display);

    glutWMCloseFunc(CloseFunc);
    
    glEnable(GL_BLEND);
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glutMainLoop();

    return 0;
}
