﻿1. 到此網址下載 FREEGLUT：
http://files.transmissionzero.co.uk/software/development/GLUT/freeglut-MinGW.zip



2. 在資料夾路徑輸入 cmd 並按 Enter



3. 在 cmd 視窗下打以下一行指令
（請將 FREEGLUT_PATH 改成你的 FREEGLUT 資料夾路徑）

g++ -c -o testgl.o testgl.cpp -D FREEGLUT_STATIC -I"(FREEGLUT_PATH)\include"
g++ -o testgl.exe testgl.o -L"(FREEGLUT_PATH)\lib" -lfreeglut_static -lopengl32 -lwinmm -lgdi32 -Wl,--subsystem,windows



4. 在 cmd 輸入 testgl.exe 即可執行