#include <cstdio>
#include <cstdlib>

#define GLUT_DISABLE_ATEXIT_HACK
#include <GL\glut.h>
#include <windows.h>

float ball_x, ball_y;
float ball_vx, ball_vy;

float bar_x, bar_y;
float bar_vx, bar_vy;
float bar_width, bar_height;

float block_x[100], block_y[100];
float block_width, block_height;
int block_cnt;

bool trigger_left_key, trigger_right_key;

int game_state;

const int GAME_STATE_PLAY = 0;
const int GAME_STATE_END = 1;

/* �P�_�O�_�O�b�Y�Ӫ���θ̭�
 * �ѼơG
 *    - x �G����x�y��
 *    - y �G����y�y��
 *    - w �G����μe��
 *    - h �G����ΰ���
 *    - cx�G����Τ���x�y��
 *    - cy�G����Τ���y�y��
 */
bool IsInBox(float x, float y, float w, float h, float cx, float cy){
    return false;
}

/* �P�_�y�ЬO�_����
 * �ѼơG
 *    - x�G����x�y��
 *    - y�G����y�y��
 */
bool IsLegalPoint(float x, float y){
    return true;
}


/* �����Q���쪺�j��
 * �ѼơG
 *    - x�Gx�y��
 *    - y�Gy�y��
 */
void BlockDelete(float x, float y){
    return;
}


void SystemTimer(int value){
    if(game_state == GAME_STATE_PLAY){
        ball_x += ball_vx;
        ball_y += ball_vy;
        if(IsLegalPoint(ball_x + ball_vx, ball_y) == false){
            BlockDelete(ball_x + ball_vx, ball_y);
            ball_vx = -ball_vx;
        }
        
        if(IsLegalPoint(ball_x, ball_y + ball_vy) == false){
            BlockDelete(ball_x, ball_y + ball_vy);
            ball_vy = -ball_vy;
        }
        
        if(trigger_left_key) bar_x -= bar_vx;
        if(trigger_right_key) bar_x += bar_vx;
        
        if(ball_y < -1) game_state = GAME_STATE_END;

    }else if(game_state == GAME_STATE_END){
        //doing nothing
    }

    glutPostRedisplay();
    glutTimerFunc(25, SystemTimer, 1);
    return;
}


void DrawRectangle(float midx, float midy,
                   float width, float height,
                   float r, float g, float b){
    glBegin(GL_QUADS);
        glColor3f(r, g, b);
        glVertex3f(midx - width/2, midy - height/2, 0.0);
        glVertex3f(midx + width/2, midy - height/2, 0.0);
        glVertex3f(midx + width/2, midy + height/2, 0.0);
        glVertex3f(midx - width/2, midy + height/2, 0.0);
    glEnd();
    return;
}
    
void Display(){
    glClear(GL_COLOR_BUFFER_BIT);
    
    if(game_state == GAME_STATE_PLAY){
        float wid = 0.05;
        DrawRectangle(ball_x, ball_y, wid, wid, 0.5, 0.5, 0.5);
        DrawRectangle(bar_x, bar_y, bar_width, bar_height, 0.5, 0.7, 0.7); 
        
        for(int lx = 0;lx < block_cnt;lx++)
            DrawRectangle(block_x[lx], block_y[lx], block_width, block_height, 0.5, 0.3, 0.3);

    }else if(game_state == GAME_STATE_END){
        // print GAME_END
        glColor3f(1,1,1);
        float x = -0.2, y = 0;
        char str[] = "GAME OVER";
        glRasterPos2f((GLfloat)x,(GLfloat)y);
        for(int c = 0; str[c] != 0; c++)
            glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, str[c]);
    }
     
    glFlush();
    return;
}

void Init(){
    bar_x = 0, bar_y = -0.5;
    bar_vx = 0.05, bar_vy = 0;
    bar_width = 0.3, bar_height = 0.015;

    ball_vx = 0.01, ball_vy = 0.012;
    ball_x = 0, ball_y = 0;

    trigger_left_key = false, trigger_right_key = false;

    block_width = 0.18, block_height = 0.09;
    block_cnt = 24;
    for(int lx = 0;lx < 4;lx++)
        for(int ly = 0;ly < 6;ly++)
            block_x[lx*6 + ly] = -0.5 + ly*0.2 ,
            block_y[lx*6 + ly] = 0.5 - lx*0.1;
    
    game_state = GAME_STATE_PLAY;

    return;
}

void SpecialKeyDown(int key, int x, int y){
    if(key == GLUT_KEY_LEFT) trigger_left_key = true; 
    if(key == GLUT_KEY_RIGHT) trigger_right_key = true; 
    glutPostRedisplay();
    return;
}

void SpecialKeyUp(int key, int x, int y){
    if(key == GLUT_KEY_LEFT) trigger_left_key = false; 
    if(key == GLUT_KEY_RIGHT) trigger_right_key = false; 
    glutPostRedisplay();
    return;
}

void NormalKeyDown(unsigned char c, int x, int y){
    glutPostRedisplay();
    return;
}

void NormalKeyUp(unsigned char c, int x, int y){
    glutPostRedisplay();
    return;
}

int main(int argc, char* argv[]){ 
    Init();
    
    glutInit(&argc, argv);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Blockhit");
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_ALPHA); 
    glutDisplayFunc(Display);

    glutTimerFunc(25, SystemTimer, 1);

    glutKeyboardFunc(NormalKeyDown);
    glutKeyboardUpFunc(NormalKeyUp);
    glutSpecialFunc(SpecialKeyDown);
    glutSpecialUpFunc(SpecialKeyUp);

    glEnable(GL_BLEND);
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glutMainLoop();

    return 0;
}

