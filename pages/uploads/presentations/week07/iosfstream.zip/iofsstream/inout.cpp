#include <iostream>
#include <fstream>
using namespace std;
int main() {
    int intVal;
    ifstream fin;
    fin.open("input.txt");
    ofstream fout;
    fout.open("output.txt");
    while (fin >> intVal) {
        fout << intVal << endl;
    }
    fin.close();
    fout.close();
    return 0;
}
