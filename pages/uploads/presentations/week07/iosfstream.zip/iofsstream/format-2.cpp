#include <iostream>
#include <iomanip>
using namespace std;
int main() {
    double pi = 3.1415926534;
    // Default
    cout << "Default: " << pi << endl;
    // setprecision(0)
    cout << "setprecision(0): " << setprecision(0) << pi << endl;
    // setprecision(8)
    cout << "setprecision(8): " << setprecision(8) << pi << endl;
    // setprecision(8) with fixed
    cout << "setprecision(8) with fixed: " << fixed << setprecision(8) << pi << endl;
    // scientific
    cout << "scientific: " << scientific << pi << endl;

    return 0;
}
