#include <iostream>
#include <iomanip>
using namespace std;
int main() {
    int a = 1239;
    // Default
    cout << "Default: " << a << endl;
    // hex
    cout << "hex: " << hex << a << endl;
    // showbase
    cout << "showbase: " << showbase << a << endl;
    // noshowbase
    cout << "noshowbase: " << noshowbase << a << endl;
    // dec
    cout << "dec: " << dec << a << endl;

    return 0;
}
