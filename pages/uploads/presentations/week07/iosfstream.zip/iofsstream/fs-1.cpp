#include <iostream>
#include <string>
#include <fstream>
using namespace std;
int main() {
    fstream fs;
    fs.open("text.txt", fstream::out|fstream::app);
    fs << "Hello, world\n";
    fs.close();
    return 0;
}
