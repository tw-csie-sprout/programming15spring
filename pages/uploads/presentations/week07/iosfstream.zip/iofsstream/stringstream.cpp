#include <iostream>
#include <sstream>
using namespace std;
int main() {
    stringstream ss;
    ss << "Hello, ";
    cout << ss.str() << "world" << endl;
    return 0;
}
