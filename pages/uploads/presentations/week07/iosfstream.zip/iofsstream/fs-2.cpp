#include <iostream>
#include <fstream>
using namespace std;
int main() {
    fstream fs;
    fs.open("text.txt", fstream::in);
    char str[100];
    fs >> str;
    cout << "str: " << str << endl;
    fs.close();
    return 0;
}
