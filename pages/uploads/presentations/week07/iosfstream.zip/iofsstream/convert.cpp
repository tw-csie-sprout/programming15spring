#include <iostream>
#include <sstream>
using namespace std;
int main() {
    stringstream ss;
    double input;
    char output[100];
    cout << "Input a double value: " << endl;
    cin >> input;
    ss << input;
    ss >> output;
    cout << "Double value in string: " << output << endl;
    return 0;
}
